# Redacted audit bundle, JRS Review Engine v8.0 preparation

Built 2026-10-02. Review it under the reviewer instructions at the end of READINESS-REPORT.md.

## Re-check offline (Node.js 22, no network, no credentials)
```
sha256sum -c SHA256SUMS.txt
node tools/validate-gates.mjs            # recomputes track status from evidence hashes
node tools/validate-gates.mjs --selftest
node tools/validate-order.mjs --selftest
```

## Withheld, and the effect of each omission

| Withheld | Effect |
|---|---|
| Engine source and system prompt (api/review-engine.js) | Protected implementation by default; the package hash is recorded in track-b/LICENSED-ASSET-SCHEDULE.json. Engine behavior claims that depend on it are NOT_CONFIRMED_FROM_SHARED_EVIDENCE. |
| Runner and package source (tools/run-smoke.mjs, package tarball) | Implementation; the offline test results are reported in READINESS-REPORT.md but cannot be re-run from this bundle. |
| corpus/EXPECTATIONS.json | Answer key for the frozen smoke corpus; withheld so it is never used to tune a later run. |
| Creator labels | None exist yet. |
